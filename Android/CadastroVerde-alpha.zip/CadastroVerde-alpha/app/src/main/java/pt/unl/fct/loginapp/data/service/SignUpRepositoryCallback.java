package pt.unl.fct.loginapp.data.service;

/* Adicionado para devolver o resultado ao SignUpViewModel */
public interface SignUpRepositoryCallback<T> {
    void onComplete(Result<T> result);
}
