package pt.unl.fct.loginapp.data.service;

/* Adicionado para devolver o resultado ao LoginViewModel */
public interface LoginRepositoryCallback<T> {
    void onComplete(Result<T> result);
}
