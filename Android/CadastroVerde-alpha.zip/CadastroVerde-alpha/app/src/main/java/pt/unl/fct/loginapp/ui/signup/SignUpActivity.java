package pt.unl.fct.loginapp.ui.signup;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import pt.unl.fct.loginapp.LoginApplication;
import pt.unl.fct.loginapp.R;
import pt.unl.fct.loginapp.databinding.ActivitySignupBinding;
import pt.unl.fct.loginapp.ui.login.LoginActivity;

public class SignUpActivity extends AppCompatActivity {

    private SignUpViewModel signUpViewModel;
    private ActivitySignupBinding binding;
    private SignUpActivity mActivity;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivitySignupBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        signUpViewModel = new ViewModelProvider(this, new SignUpViewModelFactory(((LoginApplication) getApplication()).getExecutorService()))
                .get(SignUpViewModel.class);

        final Button btnRegister = binding.btnRegister;
        final EditText edtTxtName = binding.edtTxtName;
        final EditText edtTxtEmail = binding.edtTxtEmail;
        final EditText edtTxtTel = binding.edtTxtPhone;
        final EditText edtTxtNIF = binding.edtTxtNIF;
        final EditText edtTxtPass = binding.edtTxtPassword;
        final EditText edtTxtRepeatPass = binding.edtTxtRepeatPass;


        signUpViewModel.getSingUpFormState().observe(this, new Observer<SignUpFormState>() {
            @Override
            public void onChanged(SignUpFormState signUpFormState) {
                if(signUpFormState == null)
                    return;

                btnRegister.setEnabled(signUpFormState.isDataValid());
                if(signUpFormState.getUsernameError() != null)
                    edtTxtName.setError(getString(signUpFormState.getUsernameError()));

                if(signUpFormState.getEmailError() != null)
                    edtTxtEmail.setError(getString(signUpFormState.getEmailError()));

                if(signUpFormState.getTelephoneError() != null)
                    edtTxtTel.setError(getString(signUpFormState.getTelephoneError()));

                if(signUpFormState.getNifError() != null)
                    edtTxtNIF.setError(getString(signUpFormState.getNifError()));

                if(signUpFormState.getPasswordError() != null)
                    edtTxtPass.setError(getString(signUpFormState.getPasswordError()));

                if(signUpFormState.getConfirmPassError() != null)
                    edtTxtRepeatPass.setError(getString(signUpFormState.getConfirmPassError()));
            }
        });

        signUpViewModel.getSignUpResult().observe(this, new Observer<SignUpResult>() {
            @Override
            public void onChanged(SignUpResult signUpResult) {
                if(signUpResult == null)
                    return;
                if(signUpResult.getError() != null)
                    showSignUpFailed(signUpResult.getError());

                if(signUpResult.getSuccess() != null){
                    updateUiWithUser(signUpResult.getSuccess());
                    setResult(Activity.RESULT_OK);
                    Intent doLogin = new Intent(mActivity, LoginActivity.class);
                    startActivity(doLogin);
                    finish();
                }
            }
        });
    }

    TextWatcher afterTextChangedListener = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            // ignore
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            // ignore
        }

        @Override
        public void afterTextChanged(Editable s) {
            signUpViewModel.signUpDataChanged(edtTxtEmail.getText().toString(),
                    edtTxtPassword.getText().toString());
        }
    };

    private void updateUiWithUser(RegisteredUserView model) {
        String welcome = getString(R.string.welcome) + model.getDisplayName();
        // TODO : initiate successful logged in experience
        Toast.makeText(getApplicationContext(), welcome, Toast.LENGTH_LONG).show();
    }

    private void showSignUpFailed(@StringRes Integer errorString) {
        Toast.makeText(getApplicationContext(), errorString, Toast.LENGTH_SHORT).show();
    }

}
