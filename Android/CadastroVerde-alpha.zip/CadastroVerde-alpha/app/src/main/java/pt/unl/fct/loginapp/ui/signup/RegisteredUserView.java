package pt.unl.fct.loginapp.ui.signup;

public class RegisteredUserView {
    private final String displayName;
    private final String tokenID;
    private final String userID;

    public RegisteredUserView(String displayName, String tokenID, String userID) {
        this.displayName = displayName;
        this.tokenID = tokenID;
        this.userID = userID;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getTokenID() {
        return tokenID;
    }

    public String getUserID() {
        return userID;
    }
}
