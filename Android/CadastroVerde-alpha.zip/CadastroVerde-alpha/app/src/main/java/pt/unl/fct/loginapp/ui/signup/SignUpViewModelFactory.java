package pt.unl.fct.loginapp.ui.signup;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import java.util.concurrent.Executor;

import pt.unl.fct.loginapp.data.service.SignUpDataSource;
import pt.unl.fct.loginapp.data.service.SignUpRepository;

public class SignUpViewModelFactory implements ViewModelProvider.Factory {


    private final Executor executor;

    public SignUpViewModelFactory(Executor executor) {
        this.executor = executor;
    }

    @NonNull
    @Override
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {

       if(modelClass.isAssignableFrom(SignUpViewModel.class))
           return null;
       else
           throw new IllegalArgumentException("Unknown ViewModel class");
    }
}
