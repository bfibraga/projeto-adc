package pt.unl.fct.loginapp.data.model;

public class SignUpData {

    String username;
    String email;
    String telephone;
    String nif;
    String password;
    String confirmPassword;

    public SignUpData() {

    }

    public SignUpData(String username, String email, String telephone, String nif, String password, String confirmPassword) {
        this.username = username;
        this.email = email;
        this.telephone = telephone;
        this.nif = nif;
        this.password = password;
        this.confirmPassword = confirmPassword;
    }
}
