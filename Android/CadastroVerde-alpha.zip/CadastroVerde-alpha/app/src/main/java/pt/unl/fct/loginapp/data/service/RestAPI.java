package pt.unl.fct.loginapp.data.service;

import okhttp3.ResponseBody;
import pt.unl.fct.loginapp.data.model.LoginData;
import pt.unl.fct.loginapp.data.model.LoggedInUser;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface RestAPI {
    @POST("rest/login")
    Call<LoggedInUser> doLogin(@Body LoginData credentias);

    @POST("rest/logout")
    Call<ResponseBody> logout();
}
