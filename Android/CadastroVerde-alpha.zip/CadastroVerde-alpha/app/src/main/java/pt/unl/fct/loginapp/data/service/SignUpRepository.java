package pt.unl.fct.loginapp.data.service;

import java.util.concurrent.Executor;

import pt.unl.fct.loginapp.data.model.LoggedInUser;

public class SignUpRepository {

    private static volatile SignUpRepository instance;

    private SignUpDataSource dataSource;
    private Executor executor;


    // private constructor : singleton access
    private SignUpRepository(SignUpDataSource dataSource, Executor executor) {
        this.dataSource = dataSource;
        this.executor = executor;
    }

    public static SignUpRepository getInstance(SignUpDataSource dataSource, Executor executor) {
        if (instance == null) {
            instance = new SignUpRepository(dataSource,executor);
        }
        return instance;
    }

    public void signUp(String username, String password, SignUpRepositoryCallback<LoggedInUser> callback) {
        // handle login in a separate thread
        executor.execute(new Runnable() {
            @Override
            public void run() {
                Result<LoggedInUser> result = dataSource.login(username, password);
                if (result instanceof Result.Success) {
                    setLoggedInUser(((Result.Success<LoggedInUser>) result).getData());
                }
                callback.onComplete(result);
            }
        });
    }


}
