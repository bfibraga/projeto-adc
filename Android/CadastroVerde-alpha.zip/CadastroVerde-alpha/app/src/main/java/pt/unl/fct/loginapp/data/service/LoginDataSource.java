package pt.unl.fct.loginapp.data.service;

import okhttp3.ResponseBody;
import pt.unl.fct.loginapp.data.model.LoginData;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import pt.unl.fct.loginapp.data.model.LoggedInUser;

import java.io.IOException;

/**
 * Class that handles authentication w/ login credentials and retrieves user information.
 */
public class LoginDataSource {

    private final RestAPI service;

    public LoginDataSource() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://splendid-entry-343409.appspot.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        this.service = retrofit.create(RestAPI.class);
    }

    public Result<LoggedInUser> login(String username, String password) {

        try {
            // TODO: handle loggedInUser authentication
            Call<LoggedInUser> loginService = service.doLogin(new LoginData(username, password));
            Response<LoggedInUser> loginResponse = loginService.execute();
            if (loginResponse.isSuccessful()) {
                LoggedInUser user = loginResponse.body();
                return new Result.Success<>(user);
            } else {
                return new Result.Error(new Exception("Server result code: " + loginResponse.code()));
            }
        } catch (Exception e) {
            return new Result.Error(new IOException("Error logging in", e));
        }
    }


    public Result<ResponseBody> logout() {

        try {
            Call<ResponseBody> logoutService = service.logout();
            Response<ResponseBody> logoutResponse = logoutService.execute();
            if (logoutResponse.isSuccessful()) {
                ResponseBody user = logoutResponse.body();
                return new Result.Success<>(user);
            }

            return new Result.Error(new Exception("Server result code: " + logoutResponse.code()));
        } catch (Exception e) {
            return new Result.Error(new IOException("Error logging in", e));
        }
    }
}