package pt.unl.fct.loginapp.ui.signup;

import androidx.annotation.Nullable;

public class SignUpFormState {

    @Nullable
    private final Integer usernameError, emailError, telephoneError, nifError, passwordError, confirmPassError;
    private final boolean isDataValid;

    public SignUpFormState(@Nullable Integer usernameError, @Nullable Integer emailError, @Nullable Integer telephoneError, @Nullable Integer nifError, @Nullable Integer passwordError, @Nullable Integer confirmPassError, boolean isDataValid) {
        this.usernameError = usernameError;
        this.emailError = emailError;
        this.telephoneError = telephoneError;
        this.nifError = nifError;
        this.passwordError = passwordError;
        this.confirmPassError = confirmPassError;
        this.isDataValid = false;
    }

    public SignUpFormState(boolean isDataValid) {
        this.usernameError = null;
        this.emailError = null;
        this.telephoneError = null;
        this.nifError = null;
        this.passwordError = null;
        this.confirmPassError = null;
        this.isDataValid = isDataValid;
    }

    @Nullable
    public Integer getUsernameError() {
        return usernameError;
    }

    @Nullable
    public Integer getEmailError() {
        return emailError;
    }

    @Nullable
    public Integer getTelephoneError() {
        return telephoneError;
    }

    @Nullable
    public Integer getNifError() {
        return nifError;
    }

    @Nullable
    public Integer getPasswordError() {
        return passwordError;
    }

    @Nullable
    public Integer getConfirmPassError() {
        return confirmPassError;
    }

    public boolean isDataValid() {
        return isDataValid;
    }
}
